# v1.5更新日志
 - 新增：Apple Music的莫奈取色
 - 更新：Bilibili莫奈取色由Esing的版本更换至Ylrs113的版本
 - 支持在模块描述中显示当前已开启莫奈取色的应用
 - 优化`customize.sh`

# 捐赠
如果你觉得这个模块对你有帮助，你可以考虑[支持我的开发](https://pay.jerryz.com.cn/)